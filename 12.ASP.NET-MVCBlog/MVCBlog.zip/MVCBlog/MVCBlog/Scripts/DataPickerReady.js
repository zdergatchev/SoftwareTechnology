﻿$(function () {
    $(".datafield").datapicker();
});