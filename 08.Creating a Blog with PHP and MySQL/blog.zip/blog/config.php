<?php

define('APP_ROOT', '/blog');

define('DEFAULT_CONTROLLER', 'home');
define('DEFAULT_ACTION', 'index');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'blog');
