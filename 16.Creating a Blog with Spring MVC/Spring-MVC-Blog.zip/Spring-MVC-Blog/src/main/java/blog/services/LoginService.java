package blog.services;


public interface LoginService {
    boolean authenticate(String username, String password);
}
